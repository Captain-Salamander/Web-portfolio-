(*DIMANACHKI Alexander*)

type 'a htree =
| Leaf of int * 'a
| Branch of int * 'a htree * 'a htree
let rec huff_tab (t:'a htree):('a * (int list)) list =
  match t with
  |Leaf(_,x)->[(x,[])]
  |Branch(_,g,d)->
    let vg = List.map(fun(x,bs)->(x,0::bs))(huff_tab g) in (*Liason locale*)
    let vd = List.map(fun(x,bs)->(x,1::bs))(huff_tab d) in
    vg@vd;;