(*TME3 Alexander DIMANACHKI 21112989*)
type 'a btree = Empty | Node of 'a * 'a btree * 'a btree

(*Exercice 4.1*)
let rec lt_btree (t:'a btree) (x: 'a) : bool =
  match t with
  | Empty -> true
  | Node(e,g,d)->(e<x) && (lt_btree g x) && (lt_btree d x);;

assert((lt_btree (Node (2, Node (4, Empty, Empty), Empty)) 5) = true);;
assert((lt_btree (Node (4, Node (6, Empty, Empty), Empty)) 5) = false);;   
let rec ge_btree(t:'a btree)(x:'a): bool =
  match t with
  |Empty -> true
  |Node(e,g,d)->(e>=x) && (ge_btree g x) && (ge_btree d x);;

assert((ge_btree (Node (4, Node (5, Empty, Empty), Empty)) 4) = true);;
assert((ge_btree (Node (4, Node (3, Empty, Empty), Empty)) 4) = false);;

let rec is_abr(bt:'a btree):bool =
  match bt with
  |Empty->true
  |Node(e,g,d)->(lt_btree g e) && (ge_btree d e) && (is_abr g) && (is_abr d);;

assert((is_abr Empty) = true);
assert((is_abr (Node (5, Node (2, Node (1, Empty, Empty), Node (4, Empty, Empty)),Node (6, Empty, Node (7, Empty, Empty)))))=true);;  
assert((is_abr (Node (5, Node (2, Node (1, Empty, Empty),Node (4, Empty, Empty)),Node (3, Empty, Node (7, Empty, Empty)))))=false);;

(*Exercice 4.2*)
let rec mem (bt:'a btree) (x:'a):bool =
  match bt with
  |Empty -> false
  |Node(e,Empty,Empty)-> x=e 
  |Node(e,g,d)->if(x<e) then mem g x
                else  x=e || mem d x;;

assert((mem (Node (5, Node (2, Node (1, Empty, Empty),Node (4, Empty, Empty)),Node (6, Empty, Node (7, Empty, Empty)))) 4) = true);;
assert((mem (Node (5, Node (2, Node (1, Empty, Empty),Node (4, Empty, Empty)),Node (6, Empty, Node (7, Empty, Empty)))) 8) = false);;
 
(*Exercice 4.3*)