type 'a btree = Empty | Node of 'a * 'a btree * 'a btree;;
let rec lt_btree (t:'a btree)(x:'a):bool=
  match t with 
  | Empty -> true
  | Node (e,g,d)-> (e<x) && (lt_btree g x) && (lt_btree d x);;

let rec ge_btree (t:'a btree) (x:'a) : bool =
  match t with 
  | Empty -> true
  | Node (e,g,d)-> (e>=x) && (lt_btree g x) && (lt_btree d x);;

let rec is_abr (bt: 'a btree) : bool =
  match bt with
  |Empty->true
  |Node(e,g,d)-> (ge_btree d e) && (lt_btree g e) && (is_abr g) && (is_abr d);;

let rec mem (bt: 'a btree) (x:'a) : bool =
  match bt with
    |Empty -> false
    |Node(e,g,d)->if (x=e) then true 
                  else if (e<x) then (mem d x)
                       else (mem g x);;

let rec insert (bt:'a btree) (x:'a) : 'a btree =
  match bt with 
  |Empty -> Node(x, Empty, Empty)
  |Node (e,g,d)->if (e<x) then Node(e,g,(insert d x))
                 else Node(e,(insert g x),d);;

let abr_of_list(l:'a list) : 'a btree =
  List.fold_left insert Empty l;; (*= List.fold_left(fun x y = insert x y) Empty l*)

(*let abr_of_list(l:'a list) : 'a btree =
  List.fold_left(fun x y -> insert x y) Empty l;;*)

let rec list_of_abr (bt:'a btree) : 'a list =
  match bt with 
   |Empty->[]
   |Node(e,g,d)->(list_of_abr g) @ (e :: (list_of_abr d));;

   let abr_sort (l:'a list) : 'a list =
    list_of_abr (abr_of_list l);;