let rec bin_to_int (l : int list) : int =
  match l with 
  | [] -> raise(Invalid_argument "empty list")
  | [x] -> x
  | h::t -> h + 2 * bin_to_int(t);;

let rec int_to_bin (i : int) : int list = 
  if i = 0 then []
  else i mod 2 :: int_to_bin(i/2);;

let rec comp_bin (l : int list) (n : int) : int list=
  match (l,n) with
  |([],0)-> []
  |([],n)-> 0::(comp_bin[](n-1))
  |(h::t,0)->raise(Invalid_argument"")
  |(h::t,n)->h::(comp_bin t (n-1));;

  (*if List.length(l) > n then raise(Invalid_argument "")
  else if List.length(l) = n then l
    else comp_bin(l @ [0])(n);;*)

let rec genere_list (n : int) : int list=
    if n<2 then [] else genere_list(n-1)@[n];;

let rec elimine (l : int list) (n : int) : int list =
  match l with 
  |[]->[]
  |h::t-> if (h mod n) = 0 then elimine t n else h :: elimine t n ;;

let rec ecreme (l : int list) : int list=
  match l with 
  |[]->[]
  |h::t-> h:: ecreme (elimine t h);;

let rec crible (n : int) : int list =
if n <=1 then [] else ecreme (genere_list n);;