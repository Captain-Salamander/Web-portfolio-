(*EXERCICE 1.1*)
let rec sum_chiffres (n:int) : int =
  if n <= 9
    then n
  else sum_chiffres(n/10) + n mod 10 ;;

let rec nb_chiffres (n:int) : int =
  if n <= 9 
    then 1
  else nb_chiffres (n/10) + 1 ;;
  
(*EXERCICE 1.2*)

let rec less_divider (i:int) (n:int) : int =
  if i >= n
  then 0
  else
    if n mod i =0 then i
    else less_divider (i+1) (n);;

let prime (n:int) : bool =
  if n=1 then false
  else less_divider (2) (n) = 0 ;;


let rec next_prime (n:int) : int =
  if prime n
    then n
  else next_prime (n+1);;


let rec nth_prime (n:int) : int =
  if n = 0 
    then 2
  else next_prime(nth_prime(n-1)+1);;

(*EXERCICE 1.3*)

